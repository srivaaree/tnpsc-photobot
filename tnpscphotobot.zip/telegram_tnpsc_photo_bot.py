# TODO: Paste your fully working telegram_tnpsc_photo_bot.py code here
